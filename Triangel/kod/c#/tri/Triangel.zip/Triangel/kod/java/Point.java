
/**
 *
 * @author lohnn
 */
public class Point {

    public int x, y;

    public Point(int a, int b) {
        x = a;
        y = b;
    }
}
